'use strict';

exports.getUsers = function () {
  return [{
    name: 'Node'
  }, {
    name: 'JavaScript'
  }];
};

exports.joinStrings = function (strs) {
  return strs.join(' ');
};
